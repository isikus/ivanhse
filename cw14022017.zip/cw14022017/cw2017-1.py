import re

def countstrings(filename):
    with open (filename,'r',encoding='utf-8') as infile:
        lines = infile.readlines()
        return len(lines)

def writestrings(infilename,outfilename):
    with open (outfilename,'w',encoding='utf-8') as outfile:
        outfile.write(str(countstrings(infilename)))

def makedict(corpusfilename):
    dic = {}
    with open (corpusfilename,'r',encoding='utf-8') as infile:
        lines = infile.readlines()
        for line in lines:
            getlemma = re.search('<w lemma="(.*?)"',line)
            if getlemma:
                if getlemma.group(1) in dic:
                    dic[getlemma.group(1)] = dic[getlemma.group(1)] + 1
                else:
                    dic[getlemma.group(1)] = 1
    return dic

def writeresults(wordsdict,outfilename):
    with open (outfilename,'a',encoding='utf-8') as outfile:
        wordarr = list(wordsdict.keys())
        for word in wordarr:
            outfile.write('\n'+word)

def makelemmadict(corpusfilename):
    dic = {}
    with open (corpusfilename,'r',encoding='utf-8') as infile:
        lines = infile.readlines()
        for line in lines:
            getmorph = re.search('type="(l.f.*?)"',line)
            if getmorph:
                if getmorph.group(1) in dic:
                    dic[getmorph.group(1)] = dic[getmorph.group(1)] + 1
                else:
                    dic[getmorph.group(1)] = 1
    return dic

def writelemmas(lemmasdict,outfilename):
    with open (outfilename,'w',encoding='utf-8') as outfile:
        lemmasarr = list(lemmasdict.keys())
        valuesarr = list(lemmasdict.values())
        for i in range(len(lemmasarr)):
            outfile.write(lemmasarr[i])
            outfile.write(' - ')
            outfile.write(str(valuesarr[i]))
            outfile.write('\n')

def main():
    writestrings('F.xml','out.txt')
    writeresults(makedict('F.xml'),'out.txt')
    writelemmas(makelemmadict('F.xml'),'out2.txt')

main()
